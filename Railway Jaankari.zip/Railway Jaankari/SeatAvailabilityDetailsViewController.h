//
//  SeatAvailabilityDetailsViewController.h
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeatAvailabilityDetailsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *seatAvailTableView;
@property (weak,nonatomic) NSArray *seatArr;
@property (retain,nonatomic)NSMutableArray *seatStatusMArr;
@property (retain,nonatomic)NSMutableArray *dateAvailMArr;
@end
