//
//  RescheduledTrainTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RescheduledTrainTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *trainNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *fromLbl;
@property (weak, nonatomic) IBOutlet UILabel *toLbl;
@property (weak, nonatomic) IBOutlet UILabel *noLbl;
@property (weak, nonatomic) IBOutlet UILabel *reschDateLbl;

@property (weak, nonatomic) IBOutlet UILabel *reschTimeLbl;
@property (weak, nonatomic) IBOutlet UILabel *timeDiffLbl;

@end
