//
//  NameNumberViewController.h
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NameNumberViewController : UIViewController<NSURLConnectionDelegate, NSURLConnectionDataDelegate, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nameNoTxt;
- (IBAction)trainRunningDaysBtn:(id)sender;

@end
