//
//  TrainFareViewController.h
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainFareViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *trainFareTableView;
@property (retain,nonatomic)NSMutableArray *fareMArr;
@property (retain,nonatomic)NSMutableArray *codeMArr;
@property (retain,nonatomic)NSMutableArray *nameMArr;
@end
