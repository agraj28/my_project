//
//  RouteViewController.h
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *routeTableView;
/*@property (weak,nonatomic) NSArray *routeArr;*/
@property (retain,nonatomic)NSMutableArray *routeTrainMArr;
@property (retain,nonatomic)NSMutableArray *dayMArr;
@property (retain,nonatomic)NSMutableArray *distanceMArr;
@property (retain,nonatomic)NSMutableArray *noMArr;
@property (retain,nonatomic)NSMutableArray *haltMArr;
@property (retain,nonatomic)NSMutableArray *lattitudeMArr;
@property (retain,nonatomic)NSMutableArray *longitudeMArr;
@property (retain,nonatomic)NSMutableArray *stateMArr;
@property (retain,nonatomic)NSMutableArray *fullNameMArr;
@property (retain,nonatomic)NSMutableArray *codeMArr;
@property (retain,nonatomic)NSMutableArray *scheduleArrivalMArr;
@property (retain,nonatomic)NSMutableArray *scheduleDeptMArr;


@end
