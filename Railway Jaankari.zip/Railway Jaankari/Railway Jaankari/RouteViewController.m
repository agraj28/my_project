//
//  RouteViewController.m
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "RouteViewController.h"
#import "RouteDetailTableViewCell.h"


@interface RouteViewController ()


@end

@implementation RouteViewController
@synthesize routeTableView;
@synthesize /*routeArr, */routeTrainMArr, dayMArr, distanceMArr, noMArr, haltMArr, lattitudeMArr, longitudeMArr, stateMArr, fullNameMArr, codeMArr, scheduleArrivalMArr, scheduleDeptMArr;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    routeTrainMArr=[[NSMutableArray alloc]init];
    dayMArr=[[NSMutableArray alloc]init];
    distanceMArr=[[NSMutableArray alloc]init];
    noMArr=[[NSMutableArray alloc]init];
    haltMArr=[[NSMutableArray alloc]init];
    lattitudeMArr=[[NSMutableArray alloc]init];
    longitudeMArr=[[NSMutableArray alloc]init];
    stateMArr=[[NSMutableArray alloc]init];
    fullNameMArr=[[NSMutableArray alloc]init];
    codeMArr=[[NSMutableArray alloc]init];
    scheduleArrivalMArr=[[NSMutableArray alloc]init];
    scheduleDeptMArr=[[NSMutableArray alloc]init];
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return routeTrainMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RouteDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RouteCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
    
   
    NSLog(@"%@ root String",routeTrainMArr);
        
    cell.routeLbl.text = [routeTrainMArr
    objectAtIndex:indexPath.row];
    cell.stateLbl.text = [stateMArr objectAtIndex:indexPath.row];
    cell.dayLbl.text = [dayMArr objectAtIndex:indexPath.row];
   cell.distanceLbl.text = [distanceMArr objectAtIndex:indexPath.row];
    cell.fullNameLbl.text = [fullNameMArr objectAtIndex:indexPath.row];
    cell.noLbl.text = [noMArr objectAtIndex:indexPath.row];
    cell.codeLbl.text =[codeMArr objectAtIndex:indexPath.row];
    cell.scheduleArrLbl.text = [scheduleArrivalMArr objectAtIndex:indexPath.row];
    cell.haltLbl.text = [haltMArr objectAtIndex:indexPath.row];
    cell.scheduleDeptLbl.text = [scheduleDeptMArr objectAtIndex:indexPath.row];
   cell.lattitudeLbl.text = [lattitudeMArr objectAtIndex:indexPath.row];
    cell.longitudeLbl.text = [longitudeMArr objectAtIndex:indexPath.row];
    
    
    return cell;
}

@end
