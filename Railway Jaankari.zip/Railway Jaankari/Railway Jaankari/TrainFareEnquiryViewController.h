//
//  TrainFareEnquiryViewController.h
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainFareEnquiryViewController : UIViewController<UITextFieldDelegate, NSURLConnectionDelegate,NSURLConnectionDataDelegate>

@property (weak, nonatomic) IBOutlet UITextField *trainNoTxt;
@property (weak, nonatomic) IBOutlet UITextField *sourceCodeTxt;
@property (weak, nonatomic) IBOutlet UITextField *destCodeTxt;
@property (weak, nonatomic) IBOutlet UITextField *ageText;
@property (weak, nonatomic) IBOutlet UITextField *quotaTxt;
@property (weak, nonatomic) IBOutlet UITextField *dojTxt;
- (IBAction)fareEnquiryBtn:(id)sender;
- (IBAction)clearBtn:(id)sender;

@end
