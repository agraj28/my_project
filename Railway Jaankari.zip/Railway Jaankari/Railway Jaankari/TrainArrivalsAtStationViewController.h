//
//  TrainArrivalsAtStationViewController.h
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainArrivalsAtStationViewController : UIViewController<UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate, NSURLConnectionDelegate, NSURLConnectionDataDelegate >
{
    
    __weak IBOutlet UITableView *trainArrivalTableView;
    
    __weak IBOutlet UITextField *arrStationCodeTxt;
    
    __weak IBOutlet UITextField *hourTxt;
    
    
   }

- (IBAction)trainArrivalBtn:(id)sender;

@end
