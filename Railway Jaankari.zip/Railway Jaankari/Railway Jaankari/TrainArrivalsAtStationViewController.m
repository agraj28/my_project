//
//  TrainArrivalsAtStationViewController.m
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "TrainArrivalsAtStationViewController.h"
#import "TrainArrivalTableViewCell.h"

@interface TrainArrivalsAtStationViewController ()
{
    NSURLConnection *connection;
    NSMutableData *trainArrivalData;
    NSMutableArray *trainArrivalMArr;
    NSMutableDictionary *allDataDict;
    NSArray *trainMArr;
}

@end

@implementation TrainArrivalsAtStationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    trainArrivalMArr =[[NSMutableArray alloc]init];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [arrStationCodeTxt resignFirstResponder];
    [hourTxt resignFirstResponder];
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)trainArrivalBtn:(id)sender {
    NSMutableString *url1=[[NSMutableString alloc]init];
    
    [url1 appendFormat:@"http://api.railwayapi.com/arrivals/station/"];
    NSString *stationCodeStr=arrStationCodeTxt.text;
    [url1 appendFormat:stationCodeStr];
    NSLog(@"New url1 %@",stationCodeStr);
    
    [url1 appendFormat:@"/hours/"];
    NSString *hourStr=hourTxt.text;
    [url1 appendFormat:hourStr];
    NSLog(@"New url1 %@",hourStr);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
       trainArrivalData = [[NSMutableData alloc]init];
        //trainFareVC= [self.storyboard instantiateViewControllerWithIdentifier:@"TrainFareVCID"];
        
        //[self.navigationController pushViewController:trainFareVC animated:YES];
    }else{
        NSLog(@"Error");
    }
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [trainArrivalData setLength:0];
    NSLog(@"Hi\n %@",trainArrivalData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [trainArrivalData appendData:data];
    NSLog(@"Hi\n%@",trainArrivalData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    allDataDict = [NSJSONSerialization JSONObjectWithData:trainArrivalData options:kNilOptions error:nil];
    
    trainMArr = [allDataDict valueForKey:@"train"];
    /*NSString *trainNameStr = [trainMArr valueForKey:@"name"];
    NSString *trainNumberStr = [trainMArr valueForKey:@"number"];
    
    [trainArrivalMArr addObjectsFromArray:trainArr];*/
    [trainArrivalTableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return trainMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   TrainArrivalTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TrainArrivalCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
   
    //Accessing arrivalTrainDict
    NSDictionary *arrivalTrainDict = [trainMArr objectAtIndex:indexPath.row];
    //Name
    cell.trainNameLbl.text = [arrivalTrainDict objectForKey:@"name"];
    
    //Number
    cell.trainNoLbl.text = [arrivalTrainDict objectForKey:@"number"];
    return  cell;
}

@end
