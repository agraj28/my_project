//
//  StationBetweenViewController.m
//  Railway Jaankari
//
//  Created by varun on 27/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "StationBetweenViewController.h"
#import "TrainsBetweenStationsViewController.h"

@interface StationBetweenViewController ()
{
    NSURLConnection *connection;
    NSMutableData *stationBetweenData;
    NSMutableArray *trainBetweenStationsMArr;
    NSMutableDictionary *allData;
    NSArray *trainArr, *daysArr, *classAvailArr;
    NSString *availTrainStr/*, *trainNoStr, *travelTimeStr, *sourceDeptTimeStr, *destArrivalTimeStr, *runStr, *dayStr*/;
    
    TrainsBetweenStationsViewController *trainsBetweenVC;
   /* NSMutableArray *train1, *train2, *train3, *train4;*/
    
}

@end

@implementation StationBetweenViewController
@synthesize sourceStationTxt, destStationTxt, onDateTxt, staionTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    trainBetweenStationsMArr = [[NSMutableArray alloc]init];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [sourceStationTxt resignFirstResponder];
    [destStationTxt resignFirstResponder];[onDateTxt resignFirstResponder];
    return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)searchTrainsBtn:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    
    [url1 appendFormat:@"http://api.railwayapi.com/between/source/"];
    NSString *sourceStationStr=sourceStationTxt.text;
    [url1 appendFormat:sourceStationStr];
    NSLog(@"New url1 %@",sourceStationStr);
    
    [url1 appendFormat:@"/dest/"];
    NSString *destStationStr=destStationTxt.text;
    [url1 appendFormat:destStationStr];
    NSLog(@"New url1 %@",destStationStr);
    
    [url1 appendFormat:@"/date/"];
    NSString *onDateStr=onDateTxt.text;
    [url1 appendFormat:onDateStr];
    NSLog(@"New url1 %@",onDateStr);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        stationBetweenData = [[NSMutableData alloc]init];
       // trainsBetweenVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SeatAvailVCID"];
        
        //[self.navigationController pushViewController:seatAvailVC animated:YES];
      
    }else{
        NSLog(@"Error");
    }
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [stationBetweenData setLength:0];
    NSLog(@"Hi\n %@",stationBetweenData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [stationBetweenData appendData:data];
    NSLog(@"Hi\n%@",stationBetweenData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    allData = [NSJSONSerialization JSONObjectWithData:stationBetweenData options:kNilOptions error:nil];
    trainArr = [allData valueForKey:@"train"];
      daysArr = [trainArr valueForKey:@"days"];
    classAvailArr = [trainArr valueForKey:@"classes"];
    
    
    for (int i = 0; i<trainArr.count; i++) {
          availTrainStr = [[trainArr objectAtIndex:i]valueForKey:@"name"];
        
        [trainBetweenStationsMArr addObject:availTrainStr];
        
        
        /*
        [trainsBetweenVC.trainNumberMArr addObject:[[trainArr objectAtIndex:i]valueForKey:@"number"]];
        [train1 addObject:trainsBetweenVC.trainNumberMArr];
        
        
        [trainsBetweenVC.travelMArr addObject:[[trainArr objectAtIndex:i] valueForKey:@"travel_time"]];
        [train2 addObject:trainsBetweenVC.travelMArr];
        
        
        [trainsBetweenVC.sourceDeptMArr addObject:[[trainArr objectAtIndex:i]valueForKey:@"src_departure_time"]];
        [train3 addObject:trainsBetweenVC.sourceDeptMArr];
        
        [trainsBetweenVC.destArrivalMArr addObject:[[trainArr objectAtIndex:i]valueForKey:@"dest_arrival_time"]];
        [train4 addObject:trainsBetweenVC.destArrivalMArr];
        */
        

    }
    
    [staionTableView reloadData];
    
    /*
   for(int j=0; j<daysArr.count;j++)
    {
        
    [trainsBetweenVC.runsMArr addObject:[[daysArr objectAtIndex:j]  valueForKey:@"runs"]];
      NSLog(@"%@Runstatus", trainsBetweenVC.runsMArr);
        
    [trainsBetweenVC.daysMArr addObject:[[daysArr objectAtIndex:j]  valueForKey:@"day_code"]];
      NSLog(@"%@Runstatus", trainsBetweenVC.daysMArr);
                   
    [trainBetweenStationsMArr addObject:trainsBetweenVC.runsMArr];
    [trainBetweenStationsMArr addObject:trainsBetweenVC.daysMArr];

  }
    */
    
   // [trainsBetweenVC.trainRunStatusTableView reloadData];
}
//pragma mark - Table View
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return trainBetweenStationsMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TrainsBetweenStationsCell"];
    
    cell.textLabel.textColor=[UIColor redColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.textLabel.text = [trainBetweenStationsMArr objectAtIndex:indexPath.row];
    
    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"TrainBetweenStations"]) {

        NSIndexPath *index=[self.staionTableView indexPathForSelectedRow];
        
        
    trainsBetweenVC = [segue destinationViewController];
        /*
    trainsBetweenVC.title = [trainBetweenStationsMArr objectAtIndex:index.row];
    trainsBetweenVC.trainNumberMArr=[train1 objectAtIndex:index.row];
    trainsBetweenVC.travelMArr=[train2 objectAtIndex:index.row];
        
    trainsBetweenVC.sourceDeptMArr=[train3 objectAtIndex:index.row];
        
    trainsBetweenVC.destArrivalMArr=[train4 objectAtIndex:index.row];
        
     
    trainsBetweenVC.runsMArr = [trainBetweenStationsMArr objectAtIndex:index.row];
        trainsBetweenVC.daysMArr = [trainBetweenStationsMArr objectAtIndex:index.row];
         */
        
        //New changes
        trainsBetweenVC.selectedTrainDic = [trainArr objectAtIndex:index.row];
        
    }
}

@end
