//
//  TrainFareViewController.m
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "TrainFareViewController.h"
#import "FareDetailTableViewCell.h"

@interface TrainFareViewController ()

@end

@implementation TrainFareViewController
@synthesize trainFareTableView, fareMArr, codeMArr, nameMArr;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    fareMArr = [[NSMutableArray alloc]init];
    codeMArr = [[NSMutableArray alloc]init];
    nameMArr = [[NSMutableArray alloc]init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return fareMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FareDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FareEnquiryCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
    
    NSLog(@"%@ root String",fareMArr);
    cell.fareLbl.text = [fareMArr objectAtIndex:indexPath.row];
    cell.codeLbl.text = [codeMArr objectAtIndex:indexPath.row];
    cell.nameLbl.text = [nameMArr objectAtIndex:indexPath.row];
    return cell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
