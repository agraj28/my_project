//
//  RuningDaysViewController.m
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "RuningDaysViewController.h"
#import "RunningStatusTableViewCell.h"

@interface RuningDaysViewController ()

@end

@implementation RuningDaysViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    //Accessing dictionary
    NSDictionary *trainDict = [_runningDayDict objectForKey:@"train"];
    NSString *trainNameStr = [trainDict objectForKey:@"name"];
    NSString *trainNumberStr = [trainDict objectForKey:@"number"];
    
    //Navigation Title
    self.title = trainNameStr;
    
    //Train Name
    trainNoLbl.text = trainNumberStr;
    
    //Allocating Memory
    dayMArr = [[NSMutableArray alloc] init];
    dayMArr = [trainDict valueForKey:@"days"];
    
    dayRunTableView.dataSource = self;
    dayRunTableView.delegate = self;
    [dayRunTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dayMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RunningStatusTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DayRunCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
    
    //Accessing days dict
    NSDictionary *daysDict = [dayMArr objectAtIndex:indexPath.row];
    
    //Day
    cell.dayLbl.text = [daysDict objectForKey:@"day-code"];
    
    //Runs
    cell.runsLbl.text = [daysDict objectForKey:@"runs"];
    return  cell;
}


@end
