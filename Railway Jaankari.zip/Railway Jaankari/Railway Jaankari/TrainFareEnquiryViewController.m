//
//  TrainFareEnquiryViewController.m
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "TrainFareEnquiryViewController.h"
#import "TrainFareViewController.h"

@interface TrainFareEnquiryViewController ()
{
    NSURLConnection *connection;
    NSMutableData *trainFareData;
    NSMutableArray *fareDetailsMArr;
    TrainFareViewController *trainFareVC;
    NSMutableDictionary *allDataMDict;
    NSArray *fareArr;
}
@end

@implementation TrainFareEnquiryViewController
@synthesize trainNoTxt, sourceCodeTxt, destCodeTxt, ageText, quotaTxt, dojTxt;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    fareDetailsMArr =[[NSMutableArray alloc]init];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [trainNoTxt resignFirstResponder];
    [sourceCodeTxt resignFirstResponder];
    [destCodeTxt resignFirstResponder];
    [ageText resignFirstResponder];
    [quotaTxt resignFirstResponder];
    [dojTxt resignFirstResponder];
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)fareEnquiryBtn:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    
    [url1 appendFormat:@"http://api.railwayapi.com/fare/train/"];
    NSString *trainNoStr=trainNoTxt.text;
    [url1 appendFormat:trainNoStr];
    NSLog(@"New url1 %@",trainNoStr);
    
    [url1 appendFormat:@"/source/"];
    NSString *sourceCodeStr=sourceCodeTxt.text;
    [url1 appendFormat:sourceCodeStr];
    NSLog(@"New url1 %@",sourceCodeStr);
    
    [url1 appendFormat:@"/dest/"];
    NSString *destCodeStr=destCodeTxt.text;
    [url1 appendFormat:destCodeStr];
    NSLog(@"New url1 %@",destCodeStr);
    
    [url1 appendFormat:@"/age/"];
    NSString *ageStr=ageText.text;
    [url1 appendFormat:ageStr];
    NSLog(@"New url1 %@",ageStr);
    
    [url1 appendFormat:@"/quota/"];
    NSString *quotaStr=quotaTxt.text;
    [url1 appendFormat:quotaStr];
    NSLog(@"New url1 %@",quotaStr);
    
    [url1 appendFormat:@"/doj/"];
    NSString *dojStr=dojTxt.text;
    [url1 appendFormat:dojStr];
    NSLog(@"New url1 %@",dojStr);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        trainFareData = [[NSMutableData alloc]init];
       trainFareVC= [self.storyboard instantiateViewControllerWithIdentifier:@"TrainFareVCID"];
        
        [self.navigationController pushViewController:trainFareVC animated:YES];
    }else{
        NSLog(@"Error");
    }
}



- (IBAction)clearBtn:(id)sender {
    
    trainNoTxt.text = NULL;
    sourceCodeTxt.text = NULL;
    destCodeTxt.text = NULL;
    ageText.text = NULL;
    quotaTxt.text = NULL;
    dojTxt.text = NULL;
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [trainFareData setLength:0];
    NSLog(@"Hi\n %@",trainFareData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [trainFareData appendData:data];
    NSLog(@"Hello\n %@", trainFareData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
  allDataMDict = [NSJSONSerialization JSONObjectWithData:trainFareData options:kNilOptions error:nil];
    fareArr = [allDataMDict valueForKey:@"fare"];
    for(int i=0;i<fareArr.count;i++)
    {
        
        [trainFareVC.fareMArr addObject:[[fareArr
                                                objectAtIndex:i]valueForKey:@"fare"]];
        NSLog(@"%@status", trainFareVC.fareMArr);
        
        
        [trainFareVC.codeMArr addObject:[[fareArr                                               objectAtIndex:i]valueForKey:@"code"]];
        NSLog(@"%@ date", trainFareVC.codeMArr);
        
        
        
        [trainFareVC.nameMArr addObject:[[fareArr                                               objectAtIndex:i]valueForKey:@"name"]];
        NSLog(@"%@ date", trainFareVC.nameMArr);
        
        
        
        
    }
    
    [trainFareVC.trainFareTableView reloadData];
    
}




@end
