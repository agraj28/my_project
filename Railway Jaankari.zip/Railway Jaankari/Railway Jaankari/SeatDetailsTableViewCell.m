//
//  SeatDetailsTableViewCell.m
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "SeatDetailsTableViewCell.h"

@implementation SeatDetailsTableViewCell
@synthesize seatStatusLbl, seatAvailDateLbl;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
