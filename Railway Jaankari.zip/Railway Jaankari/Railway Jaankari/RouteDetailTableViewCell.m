//
//  RouteDetailTableViewCell.m
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "RouteDetailTableViewCell.h"

@implementation RouteDetailTableViewCell
@synthesize routeLbl, stateLbl, dayLbl, distanceLbl, fullNameLbl, noLbl, codeLbl, scheduleArrLbl,haltLbl, scheduleDeptLbl, lattitudeLbl, longitudeLbl;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
