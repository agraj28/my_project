//
//  SeatDetailsTableViewCell.h
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeatDetailsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *seatStatusLbl;
@property (weak, nonatomic) IBOutlet UILabel *seatAvailDateLbl;

@end
