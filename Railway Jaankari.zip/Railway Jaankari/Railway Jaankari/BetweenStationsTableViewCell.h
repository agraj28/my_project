//
//  BetweenStationsTableViewCell.h
//  Railway Jaankari
//
//  Created by varun on 27/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BetweenStationsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *trainDayLbl;
@property (weak, nonatomic) IBOutlet UILabel *trainRunsLbl;

@end
