//
//  SeatAvailabilityViewController.h
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeatAvailabilityViewController : UIViewController<NSURLConnectionDelegate, NSURLConnectionDataDelegate, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *trainNoTxt;
@property (weak, nonatomic) IBOutlet UITextField *journeyDateTxt;
@property (weak, nonatomic) IBOutlet UITextField *sourceCodeTxt;
@property (weak, nonatomic) IBOutlet UITextField *destCodeTxt;

@property (weak, nonatomic) IBOutlet UITextField *classTxt;
@property (weak, nonatomic) IBOutlet UITextField *quotaTxt;

- (IBAction)getAvailability:(id)sender;
- (IBAction)clear:(id)sender;

/*

@property(retain,nonatomic)NSString *trainNoStr;
@property(retain,nonatomic)NSString *journeyDateStr;
@property(retain,nonatomic)NSString *sourceCodeStr;
@property(retain,nonatomic)NSString *destCodeStr;
@property(retain,nonatomic)NSString *classStr;
@property(retain,nonatomic)NSString *quotaStr;
 */

@end

