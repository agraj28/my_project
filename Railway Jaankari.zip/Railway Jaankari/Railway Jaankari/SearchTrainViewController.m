//
//  SearchTrainViewController.m
//  Railway Jaankari
//
//  Created by Admin on 21/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "SearchTrainViewController.h"
#import "LiveTrainStatusViewController.h"

@interface SearchTrainViewController ()
{
    NSURLConnection *connection;
    NSMutableArray *trainArr;
    NSMutableData *searchTraindata;
    NSDictionary *current;
    NSDictionary *station;
    NSArray *liveTrainDetailArr;
    NSString *stationNameStr;
}

@end

@implementation SearchTrainViewController
@synthesize trainNoTxt, dateJourneyTxt, stationTableView, datePicker;

#pragma View LifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    trainArr =[[NSMutableArray alloc]init];
}

#pragma mark - TextField
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [trainNoTxt resignFirstResponder];
    [dateJourneyTxt resignFirstResponder];
    
    // Get the current date
    NSDate *pickerDate = [self.datePicker date];
    return YES;
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    datePicker.hidden = NO;
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Button Actions
- (IBAction)searchTrain:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/live/train/"];
    NSString *searchTrain=trainNoTxt.text;
    [url1 appendFormat:searchTrain];
    NSLog(@"New url1 %@",searchTrain);

    [url1 appendFormat:@"/doj/"];
    NSString *journey=dateJourneyTxt.text;
    [url1 appendFormat:journey];
    NSLog(@"New url1 %@",journey);
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        searchTraindata = [[NSMutableData alloc]init];
        url1 = @"";
    }else{
        NSLog(@"Error");
    }
    
}

#pragma mark - URL Connection Delegate
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [searchTraindata setLength:0];
    NSLog(@"Hello\n %@",searchTraindata);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [searchTraindata appendData:data];
    NSLog(@"Hello\n",searchTraindata);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSDictionary *allData = [NSJSONSerialization JSONObjectWithData:searchTraindata options:kNilOptions error:nil];
    
    if (allData.count > 0) {
        current = [allData objectForKey:@"current_station"];
        station = [current objectForKey:@"station_"];
        NSString *str = [station objectForKey:@"name"];
        [trainArr addObject:str];
        [stationTableView reloadData];
        
        //Name
        //NSDictionary *stationDict = [current objectForKey:@"station_"];
        stationNameStr  = [station objectForKey:@"name"];
        
        //cell.detailTextLabel.text = stationNameStr;
        
        //schdep
        //cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"schdep"];
        
        NSString *schduleDeparatureStr = [current objectForKey:@"schdep"];
        NSString *actualDeparatureStr = [current objectForKey:@"actdep"];
        NSString *actualArrivalStr = [current objectForKey:@"actarr"];
        NSString *schArrivalDateStr = [current objectForKey:@"scharr_date"];
        NSString *statusStr = [current objectForKey:@"status"];
        
        
        liveTrainDetailArr = [NSArray arrayWithObjects:schduleDeparatureStr, actualDeparatureStr, actualArrivalStr, schArrivalDateStr,statusStr, nil];
    }
    
 
    
   }

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return trainArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    cell.textLabel.textColor=[UIColor redColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.textLabel.text = [trainArr objectAtIndex:indexPath.row];
    
    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"status"]) {
        LiveTrainStatusViewController *liveTrainVC = [segue destinationViewController];
        liveTrainVC.liveTrainArray = liveTrainDetailArr;
        liveTrainVC.title = stationNameStr;
    }
}



- (IBAction)datePickerAction:(id)sender {
    
    NSDateFormatter *dformat = [[NSDateFormatter alloc]init];
    [dformat setDateFormat:@"yyyyMMdd"];
    NSString *dtJourneyStr = [dformat stringFromDate:datePicker.date];

    dateJourneyTxt.text = dtJourneyStr;
}
@end
