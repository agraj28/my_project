//
//  TrainRouteViewController.m
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "TrainRouteViewController.h"
#import "RouteViewController.h"

@interface TrainRouteViewController ()
{
    NSURLConnection *connection;
    NSMutableData *routeTraindata;
    NSMutableArray *routeDetailsMArr;
    NSArray *routeArray;
    RouteViewController *routeVC;

}

@end

@implementation TrainRouteViewController
@synthesize trainNoLbl, trainNoTxt;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    routeDetailsMArr =[[NSMutableArray alloc]init];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [trainNoTxt resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)trainRouteBtn:(id)sender
{
    NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/route/train/"];
     NSString *routeTrain=trainNoTxt.text;
     [url1 appendFormat:routeTrain];
     [url1 appendFormat:@"/apikey/nmlxuep3/"];
     NSLog(@"url name %@",url1);
     NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
     NSURL *url=[NSURL URLWithString:fullstring];
     NSLog(@"url %@",url);
     
     
     NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
     connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
     if (connection) {
         routeTraindata = [[NSMutableData alloc]init];
         routeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RouteVCID"];
         
         [self.navigationController pushViewController:routeVC animated:YES];
         url1 = @"";
     }else{
         NSLog(@"Error");
     }
     
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
         [routeTraindata setLength:0];
         NSLog(@"Hello\n %@",routeTraindata);
     }
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
         [routeTraindata appendData:data];
    NSLog(@"Hello\n %@",routeTraindata);
     }
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
         NSLog(@"%@",error);
     }
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
        NSDictionary *allData = [NSJSONSerialization JSONObjectWithData:routeTraindata options:kNilOptions error:nil];
        routeArray = [allData valueForKey:@"route"];
    for(int i=0;i<routeArray.count;i++)
    {
       /* NSString *routeStr, *dayStr, *distanceStr,*noStr, *haltStr, *lattitudeStr, *longitudeStr, *stateStr, *fullNameStr, *codeStr, *scheduleArrStr, *scheduleDeptStr;*/
        NSNumber *routeNum = [[routeArray objectAtIndex:i]valueForKey:@"route"];
        [routeVC.routeTrainMArr addObject:[NSString stringWithFormat:@"%@",routeNum] ];
        NSNumber *dayNum = [[routeArray objectAtIndex:i]valueForKey:@"day"];
        [routeVC.dayMArr addObject:[NSString stringWithFormat:@"%@",dayNum]];
        NSNumber *distanceNum = [[routeArray objectAtIndex:i]valueForKey:@"distance"];
        [routeVC.distanceMArr addObject:[NSString stringWithFormat:@"%@",distanceNum]];
        NSNumber *noNum = [[routeArray objectAtIndex:i]valueForKey:@"no"];
        [routeVC.noMArr addObject:[NSString stringWithFormat:@"%@",noNum]];
        NSNumber *haltNum = [[routeArray objectAtIndex:i]valueForKey:@"halt"];
        [routeVC.haltMArr addObject:[NSString stringWithFormat:@"%@",haltNum]];
        NSNumber *lattitudeNum = [[routeArray objectAtIndex:i]valueForKey:@"lat"];
        [routeVC.lattitudeMArr addObject:[NSString stringWithFormat:@"%@",lattitudeNum]];
        NSNumber *longitudeNum = [[routeArray objectAtIndex:i]valueForKey:@"lng"];
        [routeVC.longitudeMArr addObject:[NSString stringWithFormat:@"%@",longitudeNum]];
        
        NSLog(@"%@halt",routeVC.haltMArr);
        [routeVC.stateMArr addObject:[[routeArray objectAtIndex:i]valueForKey:@"state"]];
        [routeVC.fullNameMArr addObject:[[routeArray objectAtIndex:i]valueForKey:@"fullname"]];
       [routeVC.codeMArr addObject:[[routeArray objectAtIndex:i]valueForKey:@"code"]];
        [routeVC.scheduleArrivalMArr addObject:[[routeArray objectAtIndex:i]valueForKey:@"scharr"]];
        [routeVC.scheduleDeptMArr addObject:[[routeArray objectAtIndex:i]valueForKey:@"schdep"]];
    }
    
    [routeVC.routeTableView reloadData];
    
 
    
   }




     
@end
