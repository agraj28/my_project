//
//  TrainsBetweenStationsViewController.h
//  Railway Jaankari
//
//  Created by varun on 27/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainsBetweenStationsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UILabel *trainNoLbl;

@property (weak, nonatomic) IBOutlet UILabel *travelTimeLbl;
@property (weak, nonatomic) IBOutlet UILabel *sorceDepttimeLbl;
@property (weak, nonatomic) IBOutlet UILabel *destArrivalTime;
@property (weak, nonatomic) IBOutlet UITableView *trainRunStatusTableView;

/*@property (weak,nonatomic) NSArray *trainRunningStatusArr;*/
@property (retain,nonatomic)NSMutableArray *daysMArr;
@property (retain,nonatomic)NSMutableArray *classAvailMArr;
//*@property (retain,nonatomic)NSMutableArray *runsMArr;*/

/*@property (retain,nonatomic) NSMutableArray *trainNumberMArr;
@property (retain,nonatomic) NSMutableArray *travelMArr;
@property (retain,nonatomic) NSMutableArray *sourceDeptMArr;
@property (retain,nonatomic) NSMutableArray *destArrivalMArr;*/

@property (retain,nonatomic) NSMutableDictionary *selectedTrainDic;
@end
