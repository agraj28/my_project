//
//  TrainRouteViewController.h
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainRouteViewController : UIViewController<NSURLConnectionDelegate, NSURLConnectionDataDelegate, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UILabel *trainNoLbl;
@property (weak, nonatomic) IBOutlet UITextField *trainNoTxt;
- (IBAction)trainRouteBtn:(id)sender;

@end
