//
//  ViewController.m
//  Railway Jaankari
//
//  Created by Admin on 21/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *trainList;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    trainList = [[NSArray alloc]initWithObjects:@"Live train Status", @"PNR Status", @"Train Route", @"Seat Availability", @"Trains Between Stations", @"Train Name/Number", @"Train Fare Enquiry", @"Train Arrivals at Station", @"Cancelled Trains", @"Rescheduled Trains",@"Station Name to Code", @"Station Code to Name", @"Station Autocomplete Suggest", @"Train Autocomplete Suggest", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return trainList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *cellIdentifier = [trainList objectAtIndex:indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.textLabel.textColor = [UIColor blueColor];
  
    
    return cell;
}

@end
