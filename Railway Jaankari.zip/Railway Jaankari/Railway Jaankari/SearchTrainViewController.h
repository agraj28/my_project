//
//  SearchTrainViewController.h
//  Railway Jaankari
//
//  Created by Admin on 21/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTrainViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate, NSURLConnectionDelegate,NSURLConnectionDataDelegate>

@property (weak, nonatomic) IBOutlet UITextField *trainNoTxt;
@property (weak, nonatomic) IBOutlet UITextField *dateJourneyTxt;
@property (weak, nonatomic) IBOutlet UITableView *stationTableView;
- (IBAction)searchTrain:(id)sender;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
- (IBAction)datePickerAction:(id)sender;

@end
