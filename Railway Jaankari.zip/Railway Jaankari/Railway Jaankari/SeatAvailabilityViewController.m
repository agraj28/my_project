//
//  SeatAvailabilityViewController.m
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "SeatAvailabilityViewController.h"
#import "SeatAvailabilityDetailsViewController.h"

@interface SeatAvailabilityViewController ()
{
    NSURLConnection *connection;
    NSMutableData *seatAvailabilitydata;
    NSMutableArray *seatAvailMArr;
    NSArray *availabilityArr;
    SeatAvailabilityDetailsViewController *seatAvailVC;
}

@end

@implementation SeatAvailabilityViewController
@synthesize trainNoTxt, journeyDateTxt, sourceCodeTxt, destCodeTxt, classTxt, quotaTxt; /*trainNoStr, journeyDateStr, sourceCodeStr, destCodeStr, classStr, quotaStr;*/

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   seatAvailMArr =[[NSMutableArray alloc]init];

}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [trainNoTxt resignFirstResponder];
    [journeyDateTxt resignFirstResponder];
    [sourceCodeTxt resignFirstResponder];
    [destCodeTxt resignFirstResponder];
    [classTxt resignFirstResponder];
    [quotaTxt resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)getAvailability:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    
    [url1 appendFormat:@"http://api.railwayapi.com/check_seat/train/"];
    NSString *trainNo=trainNoTxt.text;
    [url1 appendFormat:trainNo];
    NSLog(@"New url1 %@",trainNo);
    
    [url1 appendFormat:@"/source/"];
    NSString *sourceCode=sourceCodeTxt.text;
    [url1 appendFormat:sourceCode];
    NSLog(@"New url1 %@",sourceCode);
    
    [url1 appendFormat:@"/dest/"];
    NSString *destCode=destCodeTxt.text;
    [url1 appendFormat:destCode];
    NSLog(@"New url1 %@",destCode);
    
    [url1 appendFormat:@"/date/"];
    NSString *journeyDate=journeyDateTxt.text;
    [url1 appendFormat:journeyDate];
    NSLog(@"New url1 %@",journeyDate);
    
    [url1 appendFormat:@"/class/"];
    NSString *class=classTxt.text;
    [url1 appendFormat:class];
    NSLog(@"New url1 %@",class);
    
    [url1 appendFormat:@"/quota/"];
    NSString *quota=quotaTxt.text;
    [url1 appendFormat:quota];
    NSLog(@"New url1 %@",quota);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        seatAvailabilitydata = [[NSMutableData alloc]init];
       seatAvailVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SeatAvailVCID"];
        
        [self.navigationController pushViewController:seatAvailVC animated:YES];
        url1 = @"";
    }else{
        NSLog(@"Error");
    }
}

- (IBAction)clear:(id)sender {
    
    trainNoTxt.text = NULL;
    journeyDateTxt.text = NULL;
    sourceCodeTxt.text = NULL;
    destCodeTxt.text = NULL;
    classTxt.text = NULL;
    quotaTxt.text = NULL;

}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [seatAvailabilitydata setLength:0];
    NSLog(@"Hi\n %@",seatAvailabilitydata);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [seatAvailabilitydata appendData:data];
    NSLog(@"Hello\n %@", seatAvailabilitydata);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSDictionary *allData = [NSJSONSerialization JSONObjectWithData:seatAvailabilitydata options:kNilOptions error:nil];
    availabilityArr = [allData valueForKey:@"availability"];
    for(int i=0;i<availabilityArr.count;i++)
    {
       
        [seatAvailVC.seatStatusMArr addObject:[[availabilityArr
                                               objectAtIndex:i]valueForKey:@"status"]];
        NSLog(@"%@status", seatAvailVC.seatStatusMArr);
    
    
        [seatAvailVC.dateAvailMArr addObject:[[availabilityArr
                                                objectAtIndex:i]valueForKey:@"date"]];
        NSLog(@"%@ date", seatAvailVC.dateAvailMArr);
        
    
    
    
    
    }

    [seatAvailVC.seatAvailTableView reloadData];

}

@end
