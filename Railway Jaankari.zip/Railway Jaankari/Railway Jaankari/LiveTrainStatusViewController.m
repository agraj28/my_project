//
//  LiveTrainStatusViewController.m
//  Railway Jaankari
//
//  Created by Admin on 21/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "LiveTrainStatusViewController.h"

@interface LiveTrainStatusViewController ()

@end

@implementation LiveTrainStatusViewController
@synthesize liveTrainStatusTableView, liveTrainArray;


#pragma mark - View LifeCycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //Train Array Declaration
    liveTrainDetails = [[NSArray alloc]initWithObjects:@"Schedule Deparature", @"Actual Deparature Time", @"Actual Arrival Time", @"Schedule Arrival date", @"Status", nil];
    liveTrainStatusTableView.hidden = YES;
}

#pragma mark - TableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return liveTrainDetails.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LiveTrainStatusViewController"];
    
    cell.textLabel.textColor=[UIColor redColor];
    
    
    cell.backgroundColor=[UIColor clearColor];
    
    cell.textLabel.text = [liveTrainDetails objectAtIndex:indexPath.row];
    cell.detailTextLabel.text = [liveTrainArray objectAtIndex:indexPath.row];
    liveTrainStatusTableView.hidden=NO;
    
 //   [liveTrainStatusTableView reloadData];
    

   /* if (indexPath.row == 0) {
        //Name
        NSDictionary *stationDict = [self.liveTrainDict objectForKey:@"station_"];
        NSString *stationNameStr = [stationDict objectForKey:@"name"];
        
        cell.detailTextLabel.text = stationNameStr;
    }
    else if (indexPath.row == 1) {
        //schdep
        cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"schdep"];
    }
    else if (indexPath.row == 2) {
        cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"actdep"];
    }
    else if (indexPath.row == 3) {
        cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"actarr"];
    }
    else if (indexPath.row == 4) {
        cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"scharr_date"];
    }
    else if (indexPath.row == 5) {
        cell.detailTextLabel.text = [self.liveTrainDict objectForKey:@"status"];
    }*/

    return cell;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
