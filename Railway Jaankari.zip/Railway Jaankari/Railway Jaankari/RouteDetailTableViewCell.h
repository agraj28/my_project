//
//  RouteDetailTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 22/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *routeLbl;
@property (weak, nonatomic) IBOutlet UILabel *stateLbl;
@property (weak, nonatomic) IBOutlet UILabel *dayLbl;
@property (weak, nonatomic) IBOutlet UILabel *distanceLbl;
@property (weak, nonatomic) IBOutlet UILabel *fullNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *noLbl;
@property (weak, nonatomic) IBOutlet UILabel *codeLbl;
@property (weak, nonatomic) IBOutlet UILabel *scheduleArrLbl;
@property (weak, nonatomic) IBOutlet UILabel *haltLbl;
@property (weak, nonatomic) IBOutlet UILabel *scheduleDeptLbl;
@property (weak, nonatomic) IBOutlet UILabel *lattitudeLbl;
@property (weak, nonatomic) IBOutlet UILabel *longitudeLbl;


@end
