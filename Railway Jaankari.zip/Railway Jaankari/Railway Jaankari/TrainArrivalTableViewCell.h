//
//  TrainArrivalTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrainArrivalTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *trainNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *trainNoLbl;

@end
