//
//  RescheduledTrainsViewController.m
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "RescheduledTrainsViewController.h"
#import "RescheduledTrainTableViewCell.h"

@interface RescheduledTrainsViewController ()
{
    
    __weak IBOutlet UITableView *reschTrainTableView;
    __weak IBOutlet UITextField *reschDateTxt;
    
    
    NSURLConnection *connection;
    NSMutableData *rescheduledTrainData;
    NSMutableArray *rescheduledTrainMArr;
    NSArray *trainsArr;
    
    
}
- (IBAction)rescheduledTrainsBtn:(id)sender;

@end

@implementation RescheduledTrainsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    rescheduledTrainMArr =[[NSMutableArray alloc]init];

}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [reschDateTxt resignFirstResponder];
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)rescheduledTrainsBtn:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/rescheduled/date/"];
    NSString *reschDateStr=reschDateTxt.text;
    [url1 appendFormat:reschDateStr];
    NSLog(@"New url1 %@",reschDateStr);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        rescheduledTrainData = [[NSMutableData alloc]init];
    }else
    {
        NSLog(@"Error");
    }
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [rescheduledTrainData setLength:0];
    NSLog(@"Hi\n %@",rescheduledTrainData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [rescheduledTrainData appendData:data];
    NSLog(@"Hi\n%@",rescheduledTrainData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSMutableDictionary *allDataDict = [NSJSONSerialization JSONObjectWithData:rescheduledTrainData options:kNilOptions error:nil];
    trainsArr = [allDataDict valueForKey:@"trains"];
    [reschTrainTableView reloadData];
    
    /* for(int i=0;i<trainsArr.count;i++)
    {
        fromDict = [[trainsArr objectAtIndex:i]valueForKey:@"from"];
        toDict = [[trainsArr objectAtIndex:i]valueForKey:@"to"];
        
        
        [reschTrainTableView reloadData];
    }*/
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return trainsArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RescheduledTrainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RescheduledTrainCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
    
    NSDictionary *trainDict = [trainsArr objectAtIndex:indexPath.row];
    
    NSDictionary *fromDict = [trainDict objectForKey:@"from"];
    NSDictionary *toDict = [trainDict objectForKey:@"to"];
    //Name
    cell.trainNameLbl.text = [trainDict objectForKey:@"name"];
    
    //Number
    cell.noLbl.text = [trainDict objectForKey:@"number"];
    
    //Rescheduled Date
    cell.reschDateLbl.text = [trainDict objectForKey:@"rescheduled_date"];
    
    //Rescheduled Time
    cell.reschTimeLbl.text = [trainDict objectForKey:@"rescheduled_time"];
    
    //Time Difference
    cell.timeDiffLbl.text = [trainDict objectForKey:@"time_diff"];
    
    //from
    cell.fromLbl.text = [fromDict objectForKey:@"name"];
    
    //to
    cell.toLbl.text = [toDict objectForKey:@"name"];
    
    return  cell;
}

@end
