//
//  TrainsBetweenStationsViewController.m
//  Railway Jaankari
//
//  Created by varun on 27/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "TrainsBetweenStationsViewController.h"
#import "BetweenStationsTableViewCell.h"
#import "ClassAvailabilityTableViewCell.h"

@interface TrainsBetweenStationsViewController ()

@end

@implementation TrainsBetweenStationsViewController
@synthesize trainNoLbl, travelTimeLbl, sorceDepttimeLbl, destArrivalTime, trainRunStatusTableView;
@synthesize daysMArr, classAvailMArr/*, runsMArr, trainRunningStatusArr*/;
/*@synthesize trainNumberMArr, travelMArr, sourceDeptMArr, destArrivalMArr;*/

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title =[self.selectedTrainDic objectForKey:@"name"];
    daysMArr=[[NSMutableArray alloc]init];
    classAvailMArr = [[NSMutableArray alloc]init];
   /* runsMArr=[[NSMutableArray alloc]init];
    trainNumberMArr = [[NSMutableArray alloc]init];
    travelMArr = [[NSMutableArray alloc]init];
    sourceDeptMArr = [[NSMutableArray alloc]init];
    destArrivalMArr = [[NSMutableArray alloc]init];*/
     
    
    trainNoLbl.text = [self.selectedTrainDic objectForKey:@"number"];
    travelTimeLbl.text = [self.selectedTrainDic objectForKey:@"travel_time"];
    sorceDepttimeLbl.text = [self.selectedTrainDic objectForKey:@"src_departure_time"];
    destArrivalTime.text = [self.selectedTrainDic objectForKey:@"dest_arrival_time"];
    
    
    //Parsing data from selected dictionary
    daysMArr = [self.selectedTrainDic objectForKey:@"days"];
    classAvailMArr = [self.selectedTrainDic valueForKey:@"classes"];
    
     
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return @"Days";
    }
    else {
        return @"Class Available";
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0) {
        return daysMArr.count;
    }
    else
        return classAvailMArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 55.0;
    }
    else {
        return 66.0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        BetweenStationsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BetweenStationsCell" forIndexPath:indexPath];
        cell.textLabel.textColor=[UIColor blackColor];
        cell.backgroundColor=[UIColor clearColor];
        
        NSDictionary *daysDic = [daysMArr objectAtIndex:indexPath.row];
        cell.trainDayLbl.text = [daysDic objectForKey:@"day-code"];
        cell.trainRunsLbl.text = [daysDic objectForKey:@"runs"];
        return cell;
    }
    else  {
        
        ClassAvailabilityTableViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:@"ClassAvailableCell" forIndexPath:indexPath];
        cell1.textLabel.textColor=[UIColor blackColor];
        cell1.backgroundColor=[UIColor clearColor];
        
        NSDictionary *classAvailDic = [classAvailMArr objectAtIndex:indexPath.row];
        cell1.classCodeLbl.text = [classAvailDic objectForKey:@"class-code"];
        cell1.availClassLbl.text = [classAvailDic objectForKey:@"available"];

        return cell1;
    }
    
    
    
    
    
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
