//
//  FareDetailTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FareDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *fareLbl;
@property (weak, nonatomic) IBOutlet UILabel *codeLbl;
@property (weak, nonatomic) IBOutlet UILabel *nameLbl;

@end
