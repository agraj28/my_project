//
//  SeatAvailabilityDetailsViewController.m
//  Railway Jaankari
//
//  Created by varun on 26/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "SeatAvailabilityDetailsViewController.h"
#import "SeatDetailsTableViewCell.h"

@interface SeatAvailabilityDetailsViewController ()

@end

@implementation SeatAvailabilityDetailsViewController
@synthesize seatAvailTableView;
@synthesize seatArr, seatStatusMArr, dateAvailMArr;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    seatStatusMArr=[[NSMutableArray alloc]init];
    dateAvailMArr=[[NSMutableArray alloc]init];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table View
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return seatStatusMArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SeatDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SeatAvailabilityCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];

    NSLog(@"%@ root String",seatStatusMArr);
    cell.seatStatusLbl.text = [seatStatusMArr
    objectAtIndex:indexPath.row];
    cell.seatAvailDateLbl.text = [dateAvailMArr objectAtIndex:indexPath.row];
    return cell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
