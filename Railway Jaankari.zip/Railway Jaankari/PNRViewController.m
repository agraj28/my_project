//
//  PNRViewController.m
//  Railway Jaankari
//
//  Created by Admin on 25/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "PNRViewController.h"

@interface PNRViewController ()
{
    NSURLConnection *connection;
    NSMutableArray *pnrArr;
    NSMutableData *pnrData;
    NSArray *passenger;
    NSMutableDictionary *allData, *toStation, *reservation, *fromStation;
    NSArray *pnrStatusListArr;
    
    NSArray *detailarr;
}

@end

@implementation PNRViewController
@synthesize pnrTxt, pnrStatusTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   pnrArr =[[NSMutableArray alloc]init];

    pnrStatusListArr = [[NSArray alloc]initWithObjects:@"Date of Journey", @"Class", @"Train No.", @"Train name", @"PNR No.", @"Chart Prepared", @"From Station", @"To Station",@"Current Status", @"Booking Status", @"Total Passengers", nil];
    pnrStatusTableView.hidden = YES;

  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [pnrTxt resignFirstResponder];
    
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)pnrStatusBtn:(id)sender {
    
    NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/pnr_status/pnr/"];
    NSString *pnrNo = pnrTxt.text;
    [url1 appendFormat:pnrNo];
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        pnrData = [[NSMutableData alloc]init];
      
    }else{
        NSLog(@"Error");
    }
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [pnrData setLength:0];
    NSLog(@"Hello\n %@",pnrData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [pnrData appendData:data];
    NSLog(@"Hello\n");
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    allData = [NSJSONSerialization JSONObjectWithData:pnrData options:kNilOptions error:nil];

    passenger = [allData valueForKey:@"passengers"];
    toStation = [allData objectForKey:@"to_station"];
    fromStation = [allData objectForKey:@"from_station"];
    reservation = [allData objectForKey:@"reservation_upto"];

    //NSString *dojStr = [allData objectForKey:@"doj"];
    //NSString *classStr = [allData objectForKey:@"class"];
   // NSString *trainNoStr = [allData objectForKey:@"train_num"];
    //NSString *trainNameStr = [allData objectForKey:@"train_name"];
    //NSString *pnrNoStr = [allData objectForKey:@"pnr"];
   // NSString *chartStr = [allData objectForKey:@"chat_prepared"];
    //NSNumber *passenger =[allData objectForKey:@"total_passengers"];
    //NSString *passengerStr = [NSString stringWithFormat:@"%@",passenger];
    fromStation = [allData objectForKey:@"from_station"];
   // NSString *fromStationStr = [fromStation objectForKey:@"name"];
    toStation = [allData objectForKey:@"to_station"];
    //NSString *toStationStr = [fromStation objectForKey:@"name"];
    //NSString *currentStatusStr = [passenger valueForKey:@"current_status"];
   // NSString *bookingStatusStr = [passenger valueForKey:@"booking_status"];
    //[pnrArr addObject:dojStr];
    //[pnrArr addObject:classStr];
    //[pnrArr addObject:trainNoStr];
    //[pnrArr addObject:trainNameStr];
    //[pnrArr addObject:pnrNoStr];
    //[pnrArr addObject:chartStr];
    //[pnrArr addObject:fromStationStr];
    //[pnrArr addObject:toStationStr];
    //[pnrArr addObject:currentStatusStr];
    //[pnrArr addObject:bookingStatusStr];
    //[pnrArr addObject:passengerStr];
    
    
 
        NSString *dojStr = [allData objectForKey:@"doj"];
    
    
   
        
        NSString *classStr = [allData objectForKey:@"class"];
    
  
    
   
        
        NSString *trainNoStr = [allData objectForKey:@"train_num"];
    
    
  
        NSString *trainNameStr = [allData objectForKey:@"train_name"];
    


        NSString *pnrNoStr = [allData objectForKey:@"pnr"];
 
        

         NSString *chartStr = [allData objectForKey:@"chart_prepared"];
 

        
        NSString *fromStationStr = [fromStation objectForKey:@"name"];
    
        

        
        NSString *toStationStr = [toStation objectForKey:@"name"];
   

    
   
        
        NSString *currentStatusStr = [[passenger objectAtIndex:0]valueForKey:@"current_status"];
    
 
    
  
        
        NSString *bookingStatusStr = [[passenger objectAtIndex:0]valueForKey:@"booking_status"];


        
        NSNumber *passenger =[allData objectForKey:@"total_passengers"];
    
        NSString *passengerStr = [NSString stringWithFormat:@"%@",passenger];
    
    
    
    
    
    detailarr=[NSArray arrayWithObjects:dojStr,classStr,trainNoStr,trainNameStr,pnrNoStr,chartStr,fromStationStr,toStationStr,currentStatusStr,bookingStatusStr,passengerStr, nil];
    
    
    
    
    pnrStatusTableView.hidden = NO;
    [pnrStatusTableView reloadData];
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return pnrStatusListArr.count;
   
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    cell.textLabel.textColor=[UIColor redColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.textLabel.text = [pnrStatusListArr objectAtIndex:indexPath.row];
        cell.detailTextLabel.text = [detailarr objectAtIndex:indexPath.row];
    
    /*if (indexPath.row == 0) {
        
        NSString *dojStr = [allData objectForKey:@"doj"];
        cell.detailTextLabel.text = dojStr;
    }
    else if (indexPath.row == 1) {
        
        NSString *classStr = [allData objectForKey:@"class"];
        cell.detailTextLabel.text = classStr;
    }
    
    else if (indexPath.row == 2) {
        
        NSString *trainNoStr = [allData objectForKey:@"train_num"];
        cell.detailTextLabel.text = trainNoStr;    }
    
    else if (indexPath.row == 3) {
         NSString *trainNameStr = [allData objectForKey:@"train_name"];
        cell.detailTextLabel.text = trainNameStr;
    }
    
    else if (indexPath.row == 4){
       NSString *pnrNoStr = [allData objectForKey:@"pnr"];
        cell.detailTextLabel.text = pnrNoStr;
        
    }
    
    else if (indexPath.row == 5){
       NSString *chartStr = [allData objectForKey:@"chart_prepared"];
        cell.detailTextLabel.text = chartStr;
  
    }
 
    else if (indexPath.row == 6){
        
        NSString *fromStationStr = [fromStation objectForKey:@"name"];
        cell.detailTextLabel.text = fromStationStr;
  
    }
    
    else if (indexPath.row == 7){
        
        NSString *toStationStr = [toStation objectForKey:@"name"];
        cell.detailTextLabel.text = toStationStr;
    }
    
    else if (indexPath.row == 8){
        
        NSString *currentStatusStr = [passenger valueForKey:@"current_status"];
        cell.detailTextLabel.text = currentStatusStr;
    }
    
    else if (indexPath.row == 9) {
        
        NSString *bookingStatusStr = [passenger valueForKey:@"booking_status"];
        cell.detailTextLabel.text = bookingStatusStr;
    }
    
    else if (indexPath.row == 10) {
        
        NSNumber *passenger =[allData objectForKey:@"total_passengers"];
        NSString *passengerStr = [NSString stringWithFormat:@"%@",passenger];
        cell.detailTextLabel.text = passengerStr;
    }*/
     
        
    return cell;
}
@end
