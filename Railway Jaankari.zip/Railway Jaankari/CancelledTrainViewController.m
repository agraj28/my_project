//
//  CancelledTrainViewController.m
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "CancelledTrainViewController.h"
#import "CancelledTrainTableViewCell.h"

@interface CancelledTrainViewController ()
{
    __weak IBOutlet UITextField *cancelDateTxt;
    
    __weak IBOutlet UITableView *cancelledTableView;
    
    NSURLConnection *connection;
    NSMutableData *cancelledTrainData;
    NSMutableArray *cancelledTrainMArr;
    NSMutableDictionary *allDataDict;
    NSArray *trainsArr;
    NSDictionary *trainDict, *sourceDict, *destinationDict;

}
- (IBAction)cancelledTrainsBtn:(id)sender;


@end

@implementation CancelledTrainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    cancelledTrainMArr =[[NSMutableArray alloc]init];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [cancelDateTxt resignFirstResponder];
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)cancelledTrainsBtn:(id)sender {
  NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/cancelled/date/"];
    NSString *cancelledDateStr=cancelDateTxt.text;
    [url1 appendFormat:cancelledDateStr];
    NSLog(@"New url1 %@",cancelledDateStr);
    
    
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        cancelledTrainData = [[NSMutableData alloc]init];
    }else
    {
        NSLog(@"Error");
    }
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [cancelledTrainData setLength:0];
    NSLog(@"Hi\n %@",cancelledTrainData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [cancelledTrainData appendData:data];
    NSLog(@"Hi\n%@",cancelledTrainData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    allDataDict = [NSJSONSerialization JSONObjectWithData:cancelledTrainData options:kNilOptions error:nil];
    trainsArr = [allDataDict valueForKey:@"trains"];
    for(int i=0;i<trainsArr.count;i++)
    {
        trainDict = [[trainsArr objectAtIndex:i]valueForKey:@"train"];
        sourceDict = [[trainsArr objectAtIndex:i]valueForKey:@"source"];
        destinationDict = [[trainsArr objectAtIndex:i]valueForKey:@"dest"];
        [cancelledTableView reloadData];
    }
}
    
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return trainsArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CancelledTrainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CancelledTrainCell" forIndexPath:indexPath];
    cell.textLabel.textColor=[UIColor redColor];
    cell.textLabel.textColor=[UIColor blackColor];
    cell.backgroundColor=[UIColor clearColor];
    
   
    //Name
    cell.trainNameLbl.text = [trainDict objectForKey:@"name"];
    
    //Number
    cell.trainNoLbl.text = [trainDict objectForKey:@"number"];
    //source Station
    cell.sourceStLbl.text = [sourceDict objectForKey:@"name"];
    //destination Station
    cell.destStLbl.text = [destinationDict objectForKey:@"name"];
    return  cell;
}
@end
