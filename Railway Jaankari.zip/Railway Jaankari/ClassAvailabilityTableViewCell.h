//
//  ClassAvailabilityTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassAvailabilityTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *classCodeLbl;
@property (weak, nonatomic) IBOutlet UILabel *availClassLbl;


@end
