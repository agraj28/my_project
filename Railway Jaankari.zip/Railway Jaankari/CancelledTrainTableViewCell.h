//
//  CancelledTrainTableViewCell.h
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CancelledTrainTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *trainNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *trainNoLbl;
@property (weak, nonatomic) IBOutlet UILabel *sourceStLbl;
@property (weak, nonatomic) IBOutlet UILabel *destStLbl;

@end
