//
//  PNRViewController.h
//  Railway Jaankari
//
//  Created by Admin on 25/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PNRViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate, NSURLConnectionDelegate,NSURLConnectionDataDelegate>
@property (weak, nonatomic) IBOutlet UITextField *pnrTxt;

@property (weak, nonatomic) IBOutlet UITableView *pnrStatusTableView;

- (IBAction)pnrStatusBtn:(id)sender;

@end
