//
//  CancelledTrainViewController.h
//  Railway Jaankari
//
//  Created by Admin on 30/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CancelledTrainViewController : UIViewController<UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate, NSURLConnectionDelegate, NSURLConnectionDataDelegate >


@end
