//
//  NameNumberViewController.m
//  Railway Jaankari
//
//  Created by Admin on 29/11/1938 Saka.
//  Copyright © 1938 Saka Admin. All rights reserved.
//

#import "NameNumberViewController.h"
#import "RuningDaysViewController.h"

@interface NameNumberViewController ()
{
    NSURLConnection *connection;
    NSMutableData *trainRunData;
    NSMutableArray *runningDetailsMArr;
    NSMutableDictionary *allDataDict, *trainDict;
    NSArray *daysArr;
    RuningDaysViewController *runningDaysVC;
}

@end

@implementation NameNumberViewController
@synthesize nameNoTxt;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   runningDetailsMArr =[[NSMutableArray alloc]init];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [nameNoTxt resignFirstResponder];
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)trainRunningDaysBtn:(id)sender {
 
    NSMutableString *url1=[[NSMutableString alloc]init];
    [url1 appendFormat:@"http://api.railwayapi.com/name_number/train/"];
    
    NSString *nameNoTrainStr = nameNoTxt.text;
    [url1 appendFormat:nameNoTrainStr];
    [url1 appendFormat:@"/apikey/nmlxuep3/"];
    NSLog(@"url name %@",url1);
    NSString *fullstring=[url1 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:fullstring];
    NSLog(@"url %@",url);
    
    
    NSURLRequest *urlreq=[NSURLRequest requestWithURL:url];
    connection = [NSURLConnection connectionWithRequest:urlreq delegate:self];
    if (connection) {
        trainRunData = [[NSMutableData alloc]init];
        
       // url1 = @"";
    }else{
        NSLog(@"Error");
    }
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [trainRunData setLength:0];
    NSLog(@"Hi\n %@",trainRunData);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [trainRunData appendData:data];
    NSLog(@"Hi\n%@",trainRunData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    allDataDict = [NSJSONSerialization JSONObjectWithData:trainRunData options:kNilOptions error:nil];
 //   trainDict = [allDataDict objectForKey:@"train"];
 //   daysArr = [trainDict valueForKey:@"days"];
    
    
    /*
    NSString *nameStr = [trainDict objectForKey:@"name"];
    runningDaysVC.trainNameStr = nameStr;
    
    runningDaysVC.trainNoStr = [trainDict objectForKey:@"number"];
    
    //runningDaysVC.daysDict = trainDict;
    for(int i=0;i<daysArr.count;i++)
    {
        [runningDaysVC.dayMArr addObject:[[daysArr objectAtIndex:i]valueForKey:@"day-code"]];
        NSLog(@"%@Day",runningDaysVC.dayMArr);
        
        [runningDaysVC.runMArr addObject:[[daysArr objectAtIndex:i]valueForKey:@"runs"]];
        NSLog(@"%@Runs",runningDaysVC.runMArr);
    }
    
    [runningDaysVC.dayRunTableView reloadData];
    
    */
    
    //Running Day
    runningDaysVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RunningDaysVCID"];
    runningDaysVC.runningDayDict = allDataDict;
    [self.navigationController pushViewController:runningDaysVC animated:YES];
}
@end
