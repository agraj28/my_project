//
//  ViewController.m
//  pListProgram
//
//  Created by harry on 3/5/17.
//  Copyright (c) 2017 harry. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *img;
    NSMutableArray *txtData;
    NSMutableArray *detailData;
    int tag;
}
@end

@implementation ViewController
@synthesize tblv,txtF,detailTxtF,nameTxt,paswordTxt,btn,submitBtn;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    tblv.hidden=YES;
    txtF.hidden=YES;
    detailTxtF.hidden=YES;
    btn.hidden=YES;
    if(tag==0)
    {
   // NSString *path=[[NSBundle mainBundle]pathForResource:@"PropertyList" ofType:@"plist"];
    img=[[NSMutableArray alloc]init];
    txtData=[[NSMutableArray alloc]init];
    detailData=[[NSMutableArray alloc]init];
   // NSDictionary *dict=[[NSDictionary alloc]initWithContentsOfFile:path];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"PropertyList.plist"];
    
        if(![[NSFileManager defaultManager]fileExistsAtPath:plistPath])
        {
            plistPath=[[NSBundle mainBundle]pathForResource:@"PropertyList" ofType:@"plist"];
        }
    NSLog(@"%@ plistPath",plistPath);
        NSData *plistXML=[[NSFileManager defaultManager]contentsAtPath:plistPath];
        NSString *errorDesc=nil;
        NSPropertyListFormat format;
        NSDictionary *temp=(NSDictionary *)[NSPropertyListSerialization propertyListFromData:plistXML mutabilityOption:NSPropertyListMutableContainersAndLeaves format:&format errorDescription:&errorDesc];
    NSLog(@"%@ temp",temp);
    if(!temp)
    {
        NSLog(@"Error reading plist:%@, format:%d",errorDesc,format);
    }
    
    img=[temp objectForKey:@"images"];
    txtData=[temp objectForKey:@"TextData"];
    detailData=[temp objectForKey:@"DetailTextData"];
    }
    txtF.delegate=self;
    detailTxtF.delegate=self;
        
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return img.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.imageView.image=[UIImage imageNamed:[img objectAtIndex:indexPath.row]];
    cell.textLabel.text=[txtData objectAtIndex:indexPath.row];
    cell.detailTextLabel.text=[detailData objectAtIndex:indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    
    cell.accessoryType=UITableViewCellAccessoryCheckmark;
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    
    cell.accessoryType=UITableViewCellAccessoryNone;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionBtn:(id)sender {
    [txtF resignFirstResponder];
    [detailTxtF resignFirstResponder];
//    NSMutableArray *txt=[[NSMutableArray alloc]init];
//    NSMutableArray *data=[[NSMutableArray alloc]init];
//    NSMutableArray *img1=[[NSMutableArray alloc]init];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"PropertyList.plist"];
    
//    if(![[NSFileManager defaultManager]fileExistsAtPath:plistPath])
//    {
//        plistPath=[[NSBundle mainBundle]pathForResource:@"PropertyList" ofType:@"plist"];
//    }
//    
//    NSData *plistXML=[[NSFileManager defaultManager]contentsAtPath:plistPath];
//    NSString *errorDesc=nil;
//    NSPropertyListFormat format;
//    NSDictionary *temp=(NSDictionary *)[NSPropertyListSerialization propertyListFromData:plistXML mutabilityOption:NSPropertyListMutableContainersAndLeaves format:&format errorDescription:&errorDesc];
   // NSLog(@"%@ txtData",plistPath);
    [txtData addObject:txtF.text];
    
    [detailData addObject:detailTxtF.text];
    NSLog(@"%@ detailData",detailData);
    [img addObject:@"1.png"];
    
    NSDictionary *plistDict = [[NSDictionary alloc] initWithObjects: [NSArray arrayWithObjects: txtData, detailData, img, nil] forKeys:[NSArray arrayWithObjects:  @"TextData",@"DetailTextData",@"images", nil]];
    NSLog(@"%@",plistDict);
    NSString *error = nil;
    NSData *plistData = [NSPropertyListSerialization dataFromPropertyList:plistDict format:NSPropertyListXMLFormat_v1_0 errorDescription:&error];
    NSLog(@"%@ plistData",plistData);
    if(plistData)
    {
        [plistData writeToFile:plistPath atomically:YES];
       // NSLog(@"%@ plistData",plistData);
        NSLog(@"Data Saved Successfully");
    }
    else
    {
        NSLog(@"Data Not Saved Successfully");
    }
    
    [tblv reloadData];
}
- (IBAction)authenticate:(id)sender {
  NSString *path=[[NSBundle mainBundle]pathForResource:@"PropertyList" ofType:@"plist"];
    NSDictionary *dict=[[NSDictionary alloc]initWithContentsOfFile:path];
    
    if([nameTxt.text isEqualToString:[dict objectForKey:@"Name"]]&&[paswordTxt.text isEqualToString:[dict objectForKey:@"Password"]]
       )
    {
        tblv.hidden=NO;
        txtF.hidden=NO;
        txtF.text=nil;
        detailTxtF.hidden=NO;
        detailTxtF.text=nil;
        btn.hidden=NO;
        tag=0;
    }
    else
    {
        NSLog(@"You Are Not Authenticated");
    }
}
@end
