//
//  AppDelegate.h
//  pListProgram
//
//  Created by harry on 3/5/17.
//  Copyright (c) 2017 harry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
