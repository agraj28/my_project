//
//  ViewController.h
//  pListProgram
//
//  Created by harry on 3/5/17.
//  Copyright (c) 2017 harry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nameTxt;
@property (weak, nonatomic) IBOutlet UITextField *paswordTxt;
- (IBAction)authenticate:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tblv;
@property (weak, nonatomic) IBOutlet UITextField *txtF;
@property (weak, nonatomic) IBOutlet UITextField *detailTxtF;
- (IBAction)actionBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn;
@property (weak, nonatomic) IBOutlet UIButton *submitBtn;

@end
