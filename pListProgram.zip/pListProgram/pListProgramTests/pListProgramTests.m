//
//  pListProgramTests.m
//  pListProgramTests
//
//  Created by harry on 3/5/17.
//  Copyright (c) 2017 harry. All rights reserved.
//

#import "pListProgramTests.h"

@implementation pListProgramTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in pListProgramTests");
}

@end
