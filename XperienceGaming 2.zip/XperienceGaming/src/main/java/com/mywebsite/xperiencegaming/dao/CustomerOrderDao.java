package com.mywebsite.xperiencegaming.dao;

import com.mywebsite.xperiencegaming.model.CustomerOrder;

public interface CustomerOrderDao 

{

    void addCustomerOrder(CustomerOrder customerOrder);
}

